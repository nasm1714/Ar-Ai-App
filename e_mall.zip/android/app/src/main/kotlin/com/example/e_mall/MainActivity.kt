package com.example.e_mall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

import '../../core/Providers/FB Firestore/fbfirestore_repo.dart';
import '../Model/shops/product.model.dart';

class ProductRepo extends FirestoreRepo<Product> {
  ProductRepo()
      : super(
          'Products',
        );

  @override
  Product? toModel(Map<String, dynamic>? item) => Product.fromMap(item ?? {});

  @override
  Map<String, dynamic>? fromModel(Product? item) => item?.toMap() ?? {};
}

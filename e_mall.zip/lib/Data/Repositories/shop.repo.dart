import '../../core/Providers/FB Firestore/fbfirestore_repo.dart';
import '../Model/shops/shop.model.dart';

class ShopRepo extends FirestoreRepo<Shop> {
  ShopRepo()
      : super(
          'Shops',
        );

  @override
  Shop? toModel(Map<String, dynamic>? item) => Shop.fromMap(item ?? {});

  @override
  Map<String, dynamic>? fromModel(Shop? item) => item?.toMap() ?? {};
}

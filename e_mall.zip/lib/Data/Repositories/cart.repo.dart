import '../../core/Providers/FB Firestore/fbfirestore_repo.dart';
import '../Model/Cart/cart.dart';

class CartRepo extends FirestoreRepo<Cart> {
  CartRepo()
      : super(
          'Cart',
        );

  @override
  Cart? toModel(Map<String, dynamic>? item) => Cart.fromMap(item ?? {});

  @override
  Map<String, dynamic>? fromModel(Cart? item) => item?.toMap() ?? {};
}

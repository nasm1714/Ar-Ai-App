import 'dart:convert';

class Shop {
  String id;
  String name;
  String imgUrl;
  String websiteUrl;

  Shop({
    required this.id,
    required this.name,
    required this.imgUrl,
    required this.websiteUrl,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      'imgUrl': imgUrl,
      'websiteUrl': websiteUrl,
    };
  }

  factory Shop.fromMap(Map<String, dynamic> map) {
    return Shop(
      id: map['id'] as String,
      name: map['name'],
      imgUrl: map['imgUrl'],
      websiteUrl: map['websiteUrl'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Shop.fromJson(String source) =>
      Shop.fromMap(json.decode(source) as Map<String, dynamic>);
}

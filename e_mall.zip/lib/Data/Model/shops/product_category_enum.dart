enum ProductCategoryEnum {
  jewelry('المجوهرات'),
  kids('الاطفال'),
  beauty('الجمال'),
  accessories('الاكسسوارات'),
  clothing('الملابس');

  final String arabicName;

  const ProductCategoryEnum(this.arabicName);
}

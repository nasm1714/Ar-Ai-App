import 'dart:convert';

import 'package:e_mall/Data/Model/shops/product_category_enum.dart';

class Product {
  String id;
  String name;
  double price;
  String description;

  ProductCategoryEnum productCategoryEnum;
  String imageUrl;

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.description,
    required this.productCategoryEnum,
    required this.imageUrl,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      "price": price,
      "description": description,
      'productCategoryEnum': productCategoryEnum.index,
      'imageUrl': imageUrl,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as String,
      name: map['name'],
      description: map["description"],
      price: double.tryParse(map['price'].toString()) ?? 0.0,
      productCategoryEnum:
          ProductCategoryEnum.values[map['productCategoryEnum']],
      imageUrl: map['imageUrl'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Product.fromJson(String source) =>
      Product.fromMap(json.decode(source) as Map<String, dynamic>);
}

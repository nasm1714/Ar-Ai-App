import 'dart:convert';

import 'cart_item.dart';

class Cart {
  String cartId;
  List<CartItem> items;
  double totalPrice;

  Cart({
    required this.cartId,
    required this.items,
    required this.totalPrice,
  });

  Map<String, dynamic> toMap() {
    return {
      'cartId': cartId,
      'items': items.map((item) => item.toMap()).toList(),
      'totalPrice': totalPrice,
    };
  }

  factory Cart.fromMap(Map<String, dynamic> map) {
    return Cart(
      cartId: map['cartId'],
      items: List<CartItem>.from(
          map['items']?.map((x) => CartItem.fromMap(x)) ?? []),
      totalPrice: map['totalPrice'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Cart.fromJson(String source) =>
      Cart.fromMap(json.decode(source));
}
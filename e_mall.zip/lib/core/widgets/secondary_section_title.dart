//t2 Core Packages Imports
import 'package:flutter/material.dart';

//t2 Dependencies Imports
//t3 Services
//t3 Models
//t1 Exports

class SecondarySectionTitle extends StatelessWidget {
  // SECTION - Widget Arguments
  final String title;
  final Function? onPressed;

  //!SECTION
  //
  const SecondarySectionTitle({super.key, required this.title, this.onPressed});

  @override
  Widget build(BuildContext context) {
    // SECTION - Build Setup
    // Values
    // double w = MediaQuery.of(context).size.width;
    // double h = MediaQuery.of(context).size.height;
    // Widgets
    //
    // Widgets
    //!SECTION

    // SECTION - Build Return
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface,
              ),
        ),
        (onPressed != null)
            ? IconButton(
                onPressed: () => onPressed!(),
                icon: Icon(
                  Icons.add,
                  size: 24,
                  color: Theme.of(context).primaryColor,
                ),
              )
            : Container()
      ],
    );

    //!SECTION
  }
}

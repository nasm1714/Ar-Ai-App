//t2 Core Packages Imports
import 'package:flutter/material.dart';

//t2 Dependencies Imports
//t3 Services
//t3 Models
//t1 Exports

class StyledIconButton extends StatelessWidget {
  // SECTION - Widget Arguments
  final IconData icon;
  final String title;
  final void Function() onPressed;

  //!SECTION
  //
  const StyledIconButton(
      {super.key,
      required this.icon,
      required this.title,
      required this.onPressed});

  @override
  Widget build(BuildContext context) {
    // SECTION - Build Setup
    // Values
    // double w = MediaQuery.of(context).size.width;
    // double h = MediaQuery.of(context).size.height;
    // Widgets
    //
    // Widgets
    //!SECTION

    // SECTION - Build Return
    return IconButton(
      onPressed: () => onPressed(),
      style: ButtonStyle(
        foregroundColor: WidgetStatePropertyAll(Theme.of(context).primaryColor),
        textStyle: WidgetStatePropertyAll(
          Theme.of(context).textTheme.labelLarge,
        ),
      ),
      icon: Row(
        children: [
          Icon(
            icon,
          ),
          SizedBox(
            width: 8,
          ),
          Text(title),
        ],
      ),
    );

    //!SECTION
  }
}

//t2 Core Packages Imports
import 'package:flutter/material.dart';

//t2 Dependencies Imports
//t3 Services
//t3 Models
//t1 Exports

class UploadPhotoWidget extends StatelessWidget {
  // SECTION - Widget Arguments
  //!SECTION
  //
  const UploadPhotoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    // SECTION - Build Setup
    // Values
    // double w = MediaQuery.of(context).size.width;
    // double h = MediaQuery.of(context).size.height;
    // Widgets
    //
    // Widgets
    //!SECTION

    // SECTION - Build Return
    return ElevatedButton(
      onPressed: () {},
      style: ButtonStyle(
        foregroundColor:
            WidgetStatePropertyAll(Theme.of(context).colorScheme.primary),
        backgroundColor: WidgetStatePropertyAll(
          Theme.of(context).colorScheme.surface,
        ),
        elevation: WidgetStatePropertyAll(0),
        padding: WidgetStatePropertyAll(
          EdgeInsets.symmetric(
            vertical: 56,
          ),
        ),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Theme.of(context).colorScheme.outline),
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.photo_outlined),
          SizedBox(
            width: 8,
          ),
          Text("Upload photo"),
        ],
      ),
    );

    //!SECTION
  }
}

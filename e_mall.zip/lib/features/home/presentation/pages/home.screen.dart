//t2 Core Packages Imports
import 'package:e_mall/Data/Repositories/shop.repo.dart';
import 'package:e_mall/core/widgets/section_placeholder.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../Data/Repositories/product.repo.dart';
import '../../../Product/cart_page.dart';
import '../../../Product/product_details_screen.dart';
import '../../../profile/presentation/pages/profile.screen.dart';

//t2 Dependencies Imports
//t3 Services
//t3 Models
//t1 Exports
class HomeScreen extends StatefulWidget {
  //SECTION - Widget Arguments
  //!SECTION
  //
  const HomeScreen({
    Key? key,
  }) : super(
          key: key,
        );

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  //
  //SECTION - State Variables
  //t2 --Controllers
  //t2 --Controllers
  //
  //t2 --State

  //SECTION - Action Callbacks
  //!SECTION

  @override
  Widget build(BuildContext context) {
    //SECTION - Build Setup
    //t2 -Values
    //double w = MediaQuery.of(context).size.width;
    //double h = MediaQuery.of(context).size.height;
    //t2 -Values
    //
    //t2 -Widgets
    //t2 -Widgets
    //!SECTION
    //SECTION - Build Return
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Image.asset("assets/images/app_logo.png"),
          actions: [
            IconButton(
              icon: Icon(
                Icons.person_2_outlined,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                size: 24,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (BuildContext context) => const ProfileScreen(),
                  ),
                );
              },
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Shop Categories Filters
                TextField(
                  decoration: InputDecoration(
                    hintText: 'ابحث عن متجر',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      FilterChip(
                          label: const Text('الملابس'), onSelected: (_) {}),
                      const SizedBox(width: 8),
                      FilterChip(
                          label: const Text('الاكسسوارات'), onSelected: (_) {}),
                      const SizedBox(width: 8),
                      FilterChip(
                          label: const Text('الجمال'), onSelected: (_) {}),
                      const SizedBox(width: 8),
                      FilterChip(
                          label: const Text('الأطفال'), onSelected: (_) {}),
                      const SizedBox(width: 8),
                      FilterChip(
                          label: const Text('المجوهرات'), onSelected: (_) {}),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Invitation to Join Us
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [Colors.blue, Colors.purple]),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('تسوق بكل سهولة.',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 22)),
                            const Text('حتى لو لم تتمكن من رؤيته.',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 22)),
                            ElevatedButton(
                              onPressed: () async {
                                // todo add real url
                                // const url = "";
                                //   if (url.isNotEmpty) {
                                //   final Uri uri = Uri.parse(url);
                                //   if (await canLaunchUrl(uri)) {
                                //   await launchUrl(uri,
                                //   mode: LaunchMode.platformDefault);
                                //   } else {
                                //   debugPrint('Could not launch $url');
                                //   }
                                //   }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xff673AB7),
                                foregroundColor: Colors.white,
                              ),
                              child: const Text('انضم كشريك'),
                            ),
                          ],
                        ),
                      ),
                      Image.asset(
                          "assets/images/video-camera-dynamic-color.png"),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
                Text(
                  'جميع المتاجر',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),

                // Grid of Shops
                FutureBuilder(
                  future: ShopRepo().readAll(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.done) {
                      if (snapshot.data != null &&
                          snapshot.hasData &&
                          snapshot.data!.isNotEmpty) {
                        return GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 5,
                            mainAxisSpacing: 8,
                            crossAxisSpacing: 8,
                          ),
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) => GestureDetector(
                            onTap: () async {
                              final url = snapshot.data![index]!.websiteUrl;

                              if (url.isNotEmpty) {
                                final Uri uri = Uri.parse(url);

                                if (await canLaunchUrl(uri)) {
                                  await launchUrl(uri,
                                      mode: LaunchMode.platformDefault);
                                } else {
                                  debugPrint('Could not launch $url');
                                }
                              } else {
                                debugPrint('URL is empty');
                              }
                            },
                            child: Column(
                              children: [
                                CircleAvatar(
                                  backgroundImage: NetworkImage(
                                      snapshot.data![index]!.imgUrl),
                                ),
                                Text(snapshot.data![index]!.name),
                              ],
                            ),
                          ),
                        );
                      } else {
                        return const SectionPlaceholder(
                          title: 'لا يوجد متاجر حالية',
                        );
                      }
                    }
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  },
                ),

                const SizedBox(height: 16),

                // Top Chosen Products
                Text(
                  'منتجات مختارة لك',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                FutureBuilder(
                  future: ProductRepo().readAll(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.done) {
                      if (snapshot.data != null &&
                          snapshot.hasData &&
                          snapshot.data!.isNotEmpty) {
                        return GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 1,
                            mainAxisSpacing: 8,
                            crossAxisSpacing: 8,
                          ),
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            final item = snapshot.data![index]!;

                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute<void>(
                                    builder: (BuildContext context) =>
                                        ProductDetailsScreen(
                                      product: item,
                                    ),
                                  ),
                                );
                              },
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 4,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    /// Image with fixed height
                                    ClipRRect(
                                      borderRadius: const BorderRadius.vertical(
                                          top: Radius.circular(12)),
                                      child: Image.network(
                                        item.imageUrl,
                                        height: 120,
                                        // Fixed height for consistency
                                        width: double.infinity,
                                        fit: BoxFit
                                            .cover, // Ensure the image fills the space
                                      ),
                                    ),

                                    /// Spacing between image and text
                                    const SizedBox(height: 8),

                                    /// Category with ellipsis handling

                                    Text(
                                      item.productCategoryEnum.arabicName,
                                      textAlign: TextAlign.center,
                                      // Adjusted alignment
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelLarge,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Text(
                                      item.name,
                                      textAlign: TextAlign.center,
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      } else {
                        return const SectionPlaceholder(
                          title: 'لا يوجد منتجات حالية',
                        );
                      }
                    }
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute<void>(
                builder: (BuildContext context) => const CartPage(),
              ),
            );
          },
          label: Text(
            'سلة المشتريات',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
            ),
          ),
          icon: Icon(
            Icons.shopping_cart,
            color: Theme.of(context).colorScheme.onPrimary,
          ),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
    //!SECTION
  }
}

//t2 استيراد الحزم الأساسية
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../../../Data/Model/App%20User/app_user.model.dart';
import '../../../../Data/Repositories/user.repo.dart';
import '../../../../core/Services/Auth/auth.service.dart';
import '../../../../core/Services/Auth/models/auth.model.dart';
import '../../../../core/Services/Auth/src/Providers/auth_provider.dart';
import '../../../../core/utils/SnackBar/snackbar.helper.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/tertiary_button.dart';
import '../../../home/presentation/pages/home.screen.dart';

//t2 استيراد التبعيات
//t3 الخدمات
//t3 النماذج
//t1 التصديرات
class SignUpScreen extends StatefulWidget {
  const SignUpScreen({
    Key? key,
  }) : super(
    key: key,
  );

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _NameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _lNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  bool hasMinLength = false;
  bool hasUpperCase = false;
  bool hasLowerCase = false;
  bool hasNumber = false;
  bool hasSpecialChar = false;

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,

      child: Scaffold(
        appBar: AppBar(
          title: const Text('إنشاء حساب'),
        ),
        body: SingleChildScrollView(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'معلومات الحساب',
                      style: TextStyle(
                        fontSize: 16,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.15,
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _NameController,
                      decoration: const InputDecoration(
                        hintText: "الاسم بالكامل",
                        labelText: "الاسم بالكامل",
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'لا يمكن أن يكون الاسم بالكامل فارغًا';
                        } else if (value.length < 3) {
                          return 'الاسم بالكامل يجب أن يتكون من 3 أحرف على الأقل';
                        }
                        return null;
                      },
                      keyboardType: TextInputType.name,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _phoneNumberController,
                      decoration: const InputDecoration(
                        hintText: "05********",
                        labelText: "رقم الجوال",
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'الرجاء إدخال رقم هاتفك';
                        }
                        // if (!RegExp(r'^05\d{8}\$').hasMatch(value)) {
                        //   return 'يجب أن يبدأ رقم الهاتف بـ "05" ويتكون من 10 أرقام';
                        // }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                        hintText: "exa@example.com",
                        labelText: "البريد الإلكتروني",
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'الرجاء إدخال بريدك الإلكتروني';
                        }
                        final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
                        if (!emailRegex.hasMatch(value)) {
                          return 'يرجى إدخال عنوان بريد إلكتروني صالح';
                        }
                        return null;
                      },
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        hintText: "كلمة المرور",
                        labelText: "كلمة المرور",
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'لا يمكن أن تكون كلمة المرور فارغة';
                        } else if (value.length < 8) {
                          return 'يجب أن تكون كلمة المرور مكونة من 8 أحرف على الأقل';
                        }
                        return null;
                      },
                    ),

                    const SizedBox(height: 16),

                    SizedBox(
                      width: double.infinity,
                      child: PrimaryButton(
                        onPressed: () async {

                          if (_formKey.currentState!.validate()) {
                            AuthService authService = AuthService(
                              authProvider: FirebaseAuthProvider(
                                firebaseAuth: FirebaseAuth.instance,
                              ),
                            );

                            AuthModel? authModel = await authService.signUp(
                              _emailController.text.trim(),
                              _passwordController.text,
                            );

                            if (authModel != null) {
                              AppUser user = AppUser(
                                id: authModel.uid,
                                email: _emailController.text,
                                fName: _NameController.text,
                                phoneNumber: _phoneNumberController.text,
                              );

                              await AppUserRepo().createSingle(user, itemId: authModel.uid);
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute<void>(
                                  builder: (BuildContext context) => const HomeScreen(),
                                ),
                                    (route) => false,
                              );
                            } else {
                              SnackbarHelper.showError(context, title: 'فشل إنشاء الحساب');
                            }
                          }
                        },
                        title: "تسجيل",
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),

      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
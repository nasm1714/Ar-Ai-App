import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter_svg/svg.dart';

import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/secondary_button.dart';
import 'sign_in.screen.dart';
import 'sign_up.screen.dart';

class LandingScreen extends StatelessWidget {
  const LandingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Image Slides with AR Product Tags
    final List<Map<String, String>> slides = [
      {
        "image": "assets/images/feature1.png",
        "text": "حول منتجاتك إلى تجارب واقعية."
      },
      {
        "image": "assets/images/feature2.png",
        "text": "اجعل منتجاتك تعيش في عيون عملائك."
      },
      {
        "image": "assets/images/feature3.png",
        "text": "استكشف عالمًا جديدًا من التسوق مع الواقع المعزز."
      },
      {
        "image": "assets/images/feature4.png",
        "text": "تسوق بثقة، مع المساعد الذكي في خدمتك."
      },
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(
          children: [
            Expanded(
              child: CarouselSlider.builder(
                itemCount: slides.length,
                options: CarouselOptions(
                  height: MediaQuery.of(context).size.height * 0.7,
                  autoPlay: false,
                  enlargeCenterPage: true,
                  enableInfiniteScroll: true,
                  viewportFraction: 1.0,
                ),
                itemBuilder: (context, index, realIndex) {
                  final slide = slides[index];
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Background Image
                      Expanded(
                        child: Image.asset(
                          slide["image"]!,
                          fit: BoxFit.fitWidth
                        ),
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      // Centered Text
                      Text(
                        slide["text"]!,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),

            // Page Indicators
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                slides.length,
                    (index) => Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.purple.withOpacity(index == 0 ? 1 : 0.4),
                  ),
                ),
              ),
            ),

            // CTA Buttons
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: PrimaryButton(
                      title: "تسجيل الدخول",
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute<void>(
                            builder: (BuildContext context) => const SignInScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: SecondaryButton(
                      title: "إنشاء حساب",
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute<void>(
                            builder: (BuildContext context) => const SignUpScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 26),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget to create product tag
  Widget _buildTag(String iconPath, String label) {
    return Column(
      children: [
        SvgPicture.asset(iconPath, height: 24, width: 24, color: Colors.white),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.8),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            label,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ),
        // Dotted Line Placeholder
        Container(
          width: 2,
          height: 20,
          color: Colors.white.withOpacity(0.6),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';

import '../../../Data/Model/Cart/cart_item.dart';

class CartItemWidget extends StatelessWidget {
  const CartItemWidget({
    super.key,
    required this.cartItem,
  });

  final CartItem cartItem;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Card(
        child: ListTile(
          leading: Image.network(
            cartItem.product.imageUrl,
            width: 50,
            height: 50,
            fit: BoxFit.cover,
          ),
          title: Text(cartItem.product.name),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('السعر: ${cartItem.product.price.toStringAsFixed(2)}\$'),
              Text('الكمية: ${cartItem.quantity}'),
            ],
          ),
          trailing: Text(
            '\$${(cartItem.product.price * cartItem.quantity).toStringAsFixed(2)}',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ),
      ),
    );
  }
}

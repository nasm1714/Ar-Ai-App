import 'package:flutter/material.dart';

class PaymentOptionsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> paymentMethods = [
    {'icon': Icons.credit_card, 'title': 'بطاقة ائتمان'},
    {'icon': Icons.account_balance_wallet, 'title': 'المحفظة'},
    {'icon': Icons.paypal, 'title': 'باي بال'},
    {'icon': Icons.currency_bitcoin, 'title': 'العملات الرقمية'},
  ];

  PaymentOptionsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'اختر وسيلة الدفع',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            ...paymentMethods.map((method) => ListTile(
                  leading: Icon(method['icon'],
                      color: Theme.of(context).colorScheme.primary),
                  title: Text(method['title']),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () {
                    // تنفيذ عند اختيار وسيلة الدفع
                  },
                )),
          ],
        ),
      ),
    );
  }
}

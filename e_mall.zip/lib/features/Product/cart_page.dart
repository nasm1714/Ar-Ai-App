//t2 Core Packages Imports
import 'package:e_mall/Data/Repositories/cart.repo.dart';
import 'package:e_mall/core/Services/Auth/auth.service.dart';
import 'package:e_mall/core/utils/SnackBar/snackbar.helper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../Data/Model/Cart/cart.dart';
import '../../core/Services/Auth/src/Providers/firebase/firebase_auth_provider.dart';
import '../../core/widgets/secondary_section_title.dart';
import 'widgets/cart_item_widget.dart';
import 'widgets/payment_options_widget.dart';

//t2 Dependencies Imports
//t3 Services
//t3 Models
//t1 Exports

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  // SECTION - Widget Arguments
  // final String barCode;
  @override
  CartPageState createState() => CartPageState();
}

class CartPageState extends State<CartPage> {
  @override
  void initState() {
    super.initState();

    // final cartParams =
    //     CartParams(id: AuthService().getCurrentUserId().substring(0, 5));

    // ref.read(cartProvider.notifier).fetchCart(cartParams);
  }

  @override
  Widget build(BuildContext context) {
    // SECTION - Build Setup
    // Values
    // double w = MediaQuery.of(context).size.width;
    // double h = MediaQuery.of(context).size.height;
    // Widgets
    // final cartState = ref.watch(cartProvider);
    // Widgets
    //!SECTION

    // SECTION - Build Return
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
          appBar: AppBar(
            title: Text("سلة المشتريات"),
            centerTitle: true,
          ),
          body: FutureBuilder(
              future: CartRepo().readSingle(AuthService(
                authProvider: FirebaseAuthProvider(
                  firebaseAuth: FirebaseAuth.instance,
                ),
              ).getCurrentUserId()!),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  if (snapshot.hasError) {
                    return Center(
                      child: Text(
                        'حدث خطأ',
                        style: TextStyle(color: Colors.red),
                      ),
                    );
                  } else if (snapshot.data != null) {
                    return Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        children: [
                          SecondarySectionTitle(
                              title: "معرّف السلة: ${snapshot.data!.cartId}"),
                          SizedBox(
                            height: 8,
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemCount: snapshot.data!.items.length,
                              itemBuilder: (context, index) {
                                final cartItem = snapshot.data!.items[index];
                                return Dismissible(
                                  key: Key(cartItem.product.id),
                                  direction: DismissDirection.endToStart,
                                  onDismissed: (direction) async {
                                    Cart newCart = snapshot.data!;
                                    newCart.items.removeWhere(
                                        (item) => item.id == cartItem.id);

                                    if (newCart.items.isEmpty) {
                                      await CartRepo()
                                          .deleteSingle(newCart.cartId);
                                      Navigator.pop(context);
                                    } else {
                                      await CartRepo().updateSingle(
                                          newCart.cartId, newCart);
                                    }
                                    SnackbarHelper.showError(context,
                                        title:
                                            '${cartItem.product.name} تمت إزالته');
                                  },
                                  background: Container(
                                    color: Theme.of(context).colorScheme.error,
                                    alignment: Alignment.centerRight,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    child: Icon(
                                      Icons.delete,
                                      color:
                                          Theme.of(context).colorScheme.onError,
                                    ),
                                  ),
                                  child: CartItemWidget(cartItem: cartItem),
                                );
                              },
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),

                          PaymentOptionsWidget(),
                          SizedBox(
                            height: 16,
                          ),

                          // قسم إجمالي السعر
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  "إجمالي السعر",
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  '\$${snapshot.data!.totalPrice.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  } else {
                    return Center(
                      child: Text("سلة المشتريات فارغة!"),
                    );
                  }
                }
                return Center(child: CircularProgressIndicator());
              })),
    );
    //!SECTION
  }
}

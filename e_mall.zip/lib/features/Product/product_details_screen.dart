import 'package:e_mall/Data/Model/Cart/cart.dart';
import 'package:e_mall/Data/Repositories/cart.repo.dart';
import 'package:e_mall/core/Services/Id%20Generating/id_generating.service.dart';
import 'package:e_mall/core/utils/SnackBar/snackbar.helper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../Data/Model/Cart/cart_item.dart';
import '../../Data/Model/shops/product.model.dart';
import '../../core/Services/Auth/auth.service.dart';
import '../../core/Services/Auth/src/Providers/auth_provider.dart';

class ProductDetailsScreen extends StatelessWidget {
  final Product product;

  const ProductDetailsScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    Future<void> addToCart({required Product productEntity}) async {
      final String cartId = AuthService(
        authProvider: FirebaseAuthProvider(
          firebaseAuth: FirebaseAuth.instance,
        ),
      ).getCurrentUserId()!;

      bool? existingCart = await CartRepo().idExists(cartId);
      String itemId = IdGeneratingService.generate();

      CartItem cartItemEntity =
          CartItem(id: itemId, product: productEntity, quantity: 1);

      if (existingCart == true) {
        Cart? cart = await CartRepo().readSingle(cartId);

        cart!.items.add(cartItemEntity);
        await CartRepo().updateSingle(cartId, cart);
      } else {
        String itemId = IdGeneratingService.generate();
        CartItem cartItemModel = CartItem(
          id: itemId,
          product: productEntity,
          quantity: cartItemEntity.quantity,
        );

        double totalPrice =
            cartItemModel.product.price * cartItemModel.quantity;

        Cart cart = Cart(
          cartId: cartId,
          items: [cartItemModel],
          totalPrice: totalPrice,
        );
        await CartRepo().createSingle(itemId: cartId, cart);
      }
      SnackbarHelper.showTemplated(context, title: "تم اضافة المنتج بنجاح!");
      Navigator.pop(context);
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(product.name),
          centerTitle: true,
          backgroundColor: Colors.white,
          elevation: 0,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Image.network(
                  product.imageUrl,
                  height: 250,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                product.name,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "${product.price}",
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                product.description,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              // const Spacer(),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  minimumSize: Size(double.infinity, 50),
                ),
                onPressed: () => addToCart(productEntity: product),
                child: const Text("اضافة الى سلة المشتريات",
                    style: TextStyle(color: Colors.white)),
              ),
              SizedBox(height: 10),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.deepPurple),
                  minimumSize: Size(double.infinity, 50),
                ),
                onPressed: () {},
                child: Text("معاينة المنتج",
                    style: TextStyle(color: Colors.deepPurple)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
